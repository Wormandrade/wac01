export interface IUsuarios {
  idUsuarios?: number;
  Nombre_Usuario: string;
  Contrasenia: string;
  Estado?: number;
  Roles_idRoles?: number;
}
