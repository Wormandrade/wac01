export interface IDestino {
  idDestino?: number;
  nombre: string;
  pais: string;
  ciudad: string;
  descripcion: string;
  costo: number; 
}
