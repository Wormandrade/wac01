export interface ITurista {
  idTurista: number;
  nombre: string;
  apellido: string;
  correo: string;
  telefono: string;
}
