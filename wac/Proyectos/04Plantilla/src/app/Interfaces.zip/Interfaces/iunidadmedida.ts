export interface IUnidadMedida {
  idUnidad_Medida?: number;
  Detalle: string;
  Tipo: number;
}
